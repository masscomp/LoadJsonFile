﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoadJsonFile
{
    class Person
    {
        public string firstName;
        public string lastName;
        public bool isactive;
        public int age;
        public string gender;
        public string eyeColor;
        public string[] friends;
    }
}
